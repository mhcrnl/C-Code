using System;

namespace MonoDevelop.CodeAnalysis {
	
	public enum Confidence {
		Total,
		High,
		Normal,
		Low
	}
}
