using System;

namespace MonoDevelop.CodeAnalysis {
	
	public enum Severity {
		Critical,
		High,
		Medium,
		Low
	}
}
