using System;

namespace MonoDevelop.CodeAnalysis {
	
	public enum CodeAnalysisCommands {
		Analyze,
	}
}
