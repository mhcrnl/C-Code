using System;

namespace MonoDevelop.CodeAnalysis {
	
	public class RuleLoaderExtension { // TODO
		
		public RuleLoaderExtension ()
		{
		}
	}
}
