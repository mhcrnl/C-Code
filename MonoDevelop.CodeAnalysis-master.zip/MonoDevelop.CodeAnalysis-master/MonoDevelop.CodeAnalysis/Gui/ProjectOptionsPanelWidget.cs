
using System;

namespace MonoDevelop.CodeAnalysis
{
	public partial class ProjectOptionsPanelWidget : Gtk.Bin
	{
		
		public ProjectOptionsPanelWidget()
		{
			this.Build();
		}
	}
}
