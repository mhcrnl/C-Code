﻿// project created on 27/07/2003 at 22:36
using System;
using System.Windows.Forms;

namespace MyFormProject 
{
	class MainForm : System.Windows.Forms.Form
	{
		
		private System.Windows.Forms.Button button;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Button button11;		
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Button button13;
		private System.Windows.Forms.Button button14;
		private System.Windows.Forms.Button button15;
		private System.Windows.Forms.Button button16;
		private System.Windows.Forms.Button button17;
		private System.Windows.Forms.Button button18;
		private System.Windows.Forms.Button button19;
		private System.Windows.Forms.Button button20;
		private System.Windows.Forms.Button button21;
		private System.Windows.Forms.Button button22;
		private System.Windows.Forms.Button button23;
		
		public MainForm()
		{
			InitializeComponent();
		}
	
		// THIS METHOD IS MAINTAINED BY THE FORM DESIGNER
		// DO NOT EDIT IT MANUALLY! YOUR CHANGES ARE LIKELY TO BE LOST
		void InitializeComponent() {
			this.button20 = new System.Windows.Forms.Button();
			this.button21 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button18 = new System.Windows.Forms.Button();
			this.button19 = new System.Windows.Forms.Button();
			this.button14 = new System.Windows.Forms.Button();
			this.button17 = new System.Windows.Forms.Button();
			this.button16 = new System.Windows.Forms.Button();
			this.button15 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.button11 = new System.Windows.Forms.Button();
			this.button10 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button13 = new System.Windows.Forms.Button();
			this.button12 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button22 = new System.Windows.Forms.Button();
			this.button23 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button20
			// 
			this.button20.Location = new System.Drawing.Point(8, 616);
			this.button20.Name = "button20";
			this.button20.Size = new System.Drawing.Size(480, 32);
			this.button20.TabIndex = 19;
			this.button20.Text = "A normal button : TextAlign=BottomLeft";
			this.button20.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// button21
			// 
			this.button21.Location = new System.Drawing.Point(8, 656);
			this.button21.Name = "button21";
			this.button21.Size = new System.Drawing.Size(480, 32);
			this.button21.TabIndex = 20;
			this.button21.Text = "A normal button : TextAlign=BottomCenter";
			this.button21.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// button6
			// 
			this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button6.Location = new System.Drawing.Point(8, 128);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(480, 24);
			this.button6.TabIndex = 5;
			this.button6.Text = "A normal button : FlatStyle=Flat";
			// 
			// button18
			// 
			this.button18.Location = new System.Drawing.Point(8, 536);
			this.button18.Name = "button18";
			this.button18.Size = new System.Drawing.Size(480, 32);
			this.button18.TabIndex = 17;
			this.button18.Text = "A normal button : TextAlign=MiddleLeft";
			this.button18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// button19
			// 
			this.button19.Location = new System.Drawing.Point(8, 576);
			this.button19.Name = "button19";
			this.button19.Size = new System.Drawing.Size(480, 32);
			this.button19.TabIndex = 18;
			this.button19.Text = "A normal button : TextAlign=MiddleRight";
			this.button19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// button14
			// 
			this.button14.ForeColor = System.Drawing.Color.Red;
			this.button14.Location = new System.Drawing.Point(8, 384);
			this.button14.Name = "button14";
			this.button14.Size = new System.Drawing.Size(480, 24);
			this.button14.TabIndex = 13;
			this.button14.Text = "A normal button : ForeColor=Red";
			// 
			// button17
			// 
			this.button17.Location = new System.Drawing.Point(8, 496);
			this.button17.Name = "button17";
			this.button17.Size = new System.Drawing.Size(480, 32);
			this.button17.TabIndex = 16;
			this.button17.Text = "A normal button : TextAlign=TopRight";
			this.button17.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// button16
			// 
			this.button16.Location = new System.Drawing.Point(8, 456);
			this.button16.Name = "button16";
			this.button16.Size = new System.Drawing.Size(480, 32);
			this.button16.TabIndex = 15;
			this.button16.Text = "A normal button : TextAlign=TopCenter";
			this.button16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// button15
			// 
			this.button15.Location = new System.Drawing.Point(8, 416);
			this.button15.Name = "button15";
			this.button15.Size = new System.Drawing.Size(480, 32);
			this.button15.TabIndex = 14;
			this.button15.Text = "A normal button : TextAlign=TopLeft";
			this.button15.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			// 
			// button8
			// 
			this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button8.Location = new System.Drawing.Point(8, 192);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(480, 24);
			this.button8.TabIndex = 7;
			this.button8.Text = "A normal button : Font.Bold=true";
			// 
			// button9
			// 
			this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button9.Location = new System.Drawing.Point(8, 224);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(480, 24);
			this.button9.TabIndex = 8;
			this.button9.Text = "A normal button : Font.Italic=true";
			// 
			// button11
			// 
			this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button11.Location = new System.Drawing.Point(8, 288);
			this.button11.Name = "button11";
			this.button11.Size = new System.Drawing.Size(480, 24);
			this.button11.TabIndex = 10;
			this.button11.Text = "A normal button : Font.Underline=true";
			// 
			// button10
			// 
			this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Strikeout, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button10.Location = new System.Drawing.Point(8, 256);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(480, 24);
			this.button10.TabIndex = 9;
			this.button10.Text = "A normal button : Font.Strikeout=true";
			// 
			// button4
			// 
			this.button4.Enabled = false;
			this.button4.Location = new System.Drawing.Point(8, 64);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(480, 24);
			this.button4.TabIndex = 3;
			this.button4.Text = "A normal button : Enabled=false";
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.Red;
			this.button5.Location = new System.Drawing.Point(8, 96);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(480, 24);
			this.button5.TabIndex = 4;
			this.button5.Text = "A normal button : BackColor=Red";
			// 
			// button
			// 
			this.button.Dock = System.Windows.Forms.DockStyle.Top;
			this.button.Location = new System.Drawing.Point(0, 0);
			this.button.Name = "button";
			this.button.Size = new System.Drawing.Size(496, 24);
			this.button.TabIndex = 0;
			this.button.Text = "A normal button : Dock=Top";
			// 
			// button7
			// 
			this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button7.Location = new System.Drawing.Point(8, 160);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(480, 24);
			this.button7.TabIndex = 6;
			this.button7.Text = "A normal button : FlatStyle=Popup";
			// 
			// button13
			// 
			this.button13.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button13.Location = new System.Drawing.Point(8, 352);
			this.button13.Name = "button13";
			this.button13.Size = new System.Drawing.Size(480, 24);
			this.button13.TabIndex = 12;
			this.button13.Text = "A normal button : Font=Verdana; 8,25pt";
			// 
			// button12
			// 
			this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button12.Location = new System.Drawing.Point(8, 320);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(480, 24);
			this.button12.TabIndex = 11;
			this.button12.Text = "A normal button : Font.Size=10";
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(8, 32);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(480, 24);
			this.button2.TabIndex = 1;
			this.button2.Text = "A normal button";
			this.button2.DoubleClick += new EventHandler(MainForm_DoubleClick);
			// 
			// button3
			// 
			this.button3.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.button3.Location = new System.Drawing.Point(0, 765);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(496, 24);
			this.button3.TabIndex = 2;
			this.button3.Text = "A normal button : Dock=Bottom";
			// 
			// button22
			// 
			this.button22.Location = new System.Drawing.Point(8, 696);
			this.button22.Name = "button22";
			this.button22.Size = new System.Drawing.Size(480, 32);
			this.button22.TabIndex = 21;
			this.button22.Text = "A normal button : TextAlign=BottomRight";
			this.button22.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// button23
			// 
			this.button23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
						| System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.button23.Location = new System.Drawing.Point(8, 736);
			this.button23.Name = "button23";
			this.button23.Size = new System.Drawing.Size(480, 24);
			this.button23.TabIndex = 22;
			this.button23.Text = "A normal button : Anchor=All";
			// 
			// MainForm
			// 
			this.ClientSize = new System.Drawing.Size(496, 789);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
						this.button23,
						this.button22,
						this.button21,
						this.button20,
						this.button19,
						this.button18,
						this.button17,
						this.button16,
						this.button15,
						this.button14,
						this.button13,
						this.button12,
						this.button11,
						this.button10,
						this.button9,
						this.button8,
						this.button7,
						this.button6,
						this.button5,
						this.button4,
						this.button3,
						this.button2,
						this.button});
			this.Text = "SWF-Buttons";
			this.ResumeLayout(false);
		}
			
		[STAThread]
		public static void Main(string[] args)
		{
			Application.Run(new MainForm());
		}

		private void MainForm_DoubleClick(object sender, EventArgs e) {
			Console.WriteLine("Got doubleclick");
		}
	}			
}
