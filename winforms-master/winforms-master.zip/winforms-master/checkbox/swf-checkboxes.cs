
using System;
using System.Windows.Forms;

namespace MyFormProject 
{
	class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.CheckBox checkBox;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.CheckBox checkBox3;
		private System.Windows.Forms.CheckBox checkBox4;
		private System.Windows.Forms.CheckBox checkBox5;
		private System.Windows.Forms.CheckBox checkBox6;
		private System.Windows.Forms.CheckBox checkBox7;
		private System.Windows.Forms.CheckBox checkBox8;
		private System.Windows.Forms.CheckBox checkBox9;
		private System.Windows.Forms.CheckBox checkBox10;
		private System.Windows.Forms.CheckBox checkBox11;
		private System.Windows.Forms.CheckBox checkBox12;
		private System.Windows.Forms.CheckBox checkBox13;
		private System.Windows.Forms.CheckBox checkBox14;
		private System.Windows.Forms.CheckBox checkBox15;
		private System.Windows.Forms.CheckBox checkBox16;
		private System.Windows.Forms.CheckBox checkBox17;
		private System.Windows.Forms.CheckBox checkBox18;
		private System.Windows.Forms.CheckBox checkBox19;
		private System.Windows.Forms.CheckBox checkBox20;
		private System.Windows.Forms.CheckBox checkBox21;
		private System.Windows.Forms.CheckBox checkBox22;
		private System.Windows.Forms.CheckBox checkBox23;
		private System.Windows.Forms.CheckBox checkBox24;
		private System.Windows.Forms.CheckBox checkBox25;
		private System.Windows.Forms.CheckBox checkBox26;
		private System.Windows.Forms.CheckBox checkBox27;
		private System.Windows.Forms.CheckBox checkBox28;
		private System.Windows.Forms.CheckBox checkBox29;
		private System.Windows.Forms.CheckBox checkBox30;
		private System.Windows.Forms.CheckBox checkBox31;
		private System.Windows.Forms.CheckBox checkBox32;
		private System.Windows.Forms.CheckBox checkBox33;
		private System.Windows.Forms.CheckBox checkBox34;
		
		public MainForm()
		{
			InitializeComponent();
		}
	
		// THIS METHOD IS MAINTAINED BY THE FORM DESIGNER
		// DO NOT EDIT IT MANUALLY! YOUR CHANGES ARE LIKELY TO BE LOST
		void InitializeComponent() {
			this.checkBox = new System.Windows.Forms.CheckBox();
			this.checkBox18 = new System.Windows.Forms.CheckBox();
			this.checkBox19 = new System.Windows.Forms.CheckBox();
			this.checkBox10 = new System.Windows.Forms.CheckBox();
			this.checkBox11 = new System.Windows.Forms.CheckBox();
			this.checkBox12 = new System.Windows.Forms.CheckBox();
			this.checkBox13 = new System.Windows.Forms.CheckBox();
			this.checkBox14 = new System.Windows.Forms.CheckBox();
			this.checkBox15 = new System.Windows.Forms.CheckBox();
			this.checkBox16 = new System.Windows.Forms.CheckBox();
			this.checkBox17 = new System.Windows.Forms.CheckBox();
			this.checkBox29 = new System.Windows.Forms.CheckBox();
			this.checkBox28 = new System.Windows.Forms.CheckBox();
			this.checkBox23 = new System.Windows.Forms.CheckBox();
			this.checkBox22 = new System.Windows.Forms.CheckBox();
			this.checkBox21 = new System.Windows.Forms.CheckBox();
			this.checkBox20 = new System.Windows.Forms.CheckBox();
			this.checkBox27 = new System.Windows.Forms.CheckBox();
			this.checkBox26 = new System.Windows.Forms.CheckBox();
			this.checkBox25 = new System.Windows.Forms.CheckBox();
			this.checkBox24 = new System.Windows.Forms.CheckBox();
			this.checkBox9 = new System.Windows.Forms.CheckBox();
			this.checkBox8 = new System.Windows.Forms.CheckBox();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.checkBox5 = new System.Windows.Forms.CheckBox();
			this.checkBox4 = new System.Windows.Forms.CheckBox();
			this.checkBox7 = new System.Windows.Forms.CheckBox();
			this.checkBox6 = new System.Windows.Forms.CheckBox();
			this.checkBox32 = new System.Windows.Forms.CheckBox();
			this.checkBox33 = new System.Windows.Forms.CheckBox();
			this.checkBox30 = new System.Windows.Forms.CheckBox();
			this.checkBox31 = new System.Windows.Forms.CheckBox();
			this.checkBox34 = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// checkBox
			// 
			this.checkBox.Dock = System.Windows.Forms.DockStyle.Top;
			this.checkBox.Location = new System.Drawing.Point(0, 0);
			this.checkBox.Name = "checkBox";
			this.checkBox.Size = new System.Drawing.Size(584, 24);
			this.checkBox.TabIndex = 0;
			this.checkBox.Text = "A normal CheckBox : Dock=Top";
			// 
			// checkBox18
			// 
			this.checkBox18.Location = new System.Drawing.Point(288, 160);
			this.checkBox18.Name = "checkBox18";
			this.checkBox18.Size = new System.Drawing.Size(280, 24);
			this.checkBox18.TabIndex = 24;
			this.checkBox18.Text = "A normal CheckBox : TextAlign=TopCenter";
			this.checkBox18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// checkBox19
			// 
			this.checkBox19.Location = new System.Drawing.Point(288, 192);
			this.checkBox19.Name = "checkBox19";
			this.checkBox19.Size = new System.Drawing.Size(280, 24);
			this.checkBox19.TabIndex = 25;
			this.checkBox19.Text = "A normal CheckBox : TextAlign=TopRight";
			this.checkBox19.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// checkBox10
			// 
			this.checkBox10.CheckAlign = System.Drawing.ContentAlignment.BottomRight;
			this.checkBox10.Location = new System.Drawing.Point(8, 304);
			this.checkBox10.Name = "checkBox10";
			this.checkBox10.Size = new System.Drawing.Size(264, 24);
			this.checkBox10.TabIndex = 17;
			this.checkBox10.Text = "A normal CheckBox : CheckAlign=BottomRight";
			// 
			// checkBox11
			// 
			this.checkBox11.Location = new System.Drawing.Point(8, 336);
			this.checkBox11.Name = "checkBox11";
			this.checkBox11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.checkBox11.Size = new System.Drawing.Size(264, 24);
			this.checkBox11.TabIndex = 19;
			this.checkBox11.Text = "A normal CheckBox : RightToLeft=True";
			// 
			// checkBox12
			// 
			this.checkBox12.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.checkBox12.Location = new System.Drawing.Point(0, 566);
			this.checkBox12.Name = "checkBox12";
			this.checkBox12.Size = new System.Drawing.Size(584, 24);
			this.checkBox12.TabIndex = 11;
			this.checkBox12.Text = "A normal CheckBox : Dock=Bottom";
			// 
			// checkBox13
			// 
			this.checkBox13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
						| System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.checkBox13.Location = new System.Drawing.Point(0, 536);
			this.checkBox13.Name = "checkBox13";
			this.checkBox13.Size = new System.Drawing.Size(264, 24);
			this.checkBox13.TabIndex = 20;
			this.checkBox13.Text = "A normal CheckBox : Anchor=All";
			// 
			// checkBox14
			// 
			this.checkBox14.Checked = true;
			this.checkBox14.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox14.Location = new System.Drawing.Point(288, 32);
			this.checkBox14.Name = "checkBox14";
			this.checkBox14.Size = new System.Drawing.Size(280, 24);
			this.checkBox14.TabIndex = 18;
			this.checkBox14.Text = "A normal CheckBox : Checked=True";
			// 
			// checkBox15
			// 
			this.checkBox15.Location = new System.Drawing.Point(288, 64);
			this.checkBox15.Name = "checkBox15";
			this.checkBox15.Size = new System.Drawing.Size(280, 24);
			this.checkBox15.TabIndex = 21;
			this.checkBox15.Text = "A normal CheckBox : TextAlign=MiddleCenter";
			this.checkBox15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// checkBox16
			// 
			this.checkBox16.Location = new System.Drawing.Point(288, 96);
			this.checkBox16.Name = "checkBox16";
			this.checkBox16.Size = new System.Drawing.Size(280, 24);
			this.checkBox16.TabIndex = 22;
			this.checkBox16.Text = "A normal CheckBox : TextAlign=MiddleRight";
			this.checkBox16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBox17
			// 
			this.checkBox17.Location = new System.Drawing.Point(288, 128);
			this.checkBox17.Name = "checkBox17";
			this.checkBox17.Size = new System.Drawing.Size(280, 24);
			this.checkBox17.TabIndex = 23;
			this.checkBox17.Text = "A normal CheckBox : TextAlign=TopLeft";
			this.checkBox17.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			// 
			// checkBox29
			// 
			this.checkBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBox29.Location = new System.Drawing.Point(288, 416);
			this.checkBox29.Name = "checkBox29";
			this.checkBox29.Size = new System.Drawing.Size(280, 24);
			this.checkBox29.TabIndex = 34;
			this.checkBox29.Text = "A normal CheckBox : Font.Italic=True";
			// 
			// checkBox28
			// 
			this.checkBox28.ForeColor = System.Drawing.Color.Green;
			this.checkBox28.Location = new System.Drawing.Point(8, 400);
			this.checkBox28.Name = "checkBox28";
			this.checkBox28.Size = new System.Drawing.Size(264, 24);
			this.checkBox28.TabIndex = 33;
			this.checkBox28.Text = "A normal CheckBox : ForeColor=Green";
			// 
			// checkBox23
			// 
			this.checkBox23.Location = new System.Drawing.Point(288, 288);
			this.checkBox23.Name = "checkBox23";
			this.checkBox23.Size = new System.Drawing.Size(280, 24);
			this.checkBox23.TabIndex = 28;
			this.checkBox23.Text = "A normal CheckBox : TextAlign=BottomRight";
			this.checkBox23.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// checkBox22
			// 
			this.checkBox22.Location = new System.Drawing.Point(296, 288);
			this.checkBox22.Name = "checkBox22";
			this.checkBox22.Size = new System.Drawing.Size(280, 24);
			this.checkBox22.TabIndex = 28;
			this.checkBox22.Text = "A normal CheckBox : TextAlign=BottomRight";
			this.checkBox22.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// checkBox21
			// 
			this.checkBox21.Location = new System.Drawing.Point(288, 256);
			this.checkBox21.Name = "checkBox21";
			this.checkBox21.Size = new System.Drawing.Size(280, 24);
			this.checkBox21.TabIndex = 27;
			this.checkBox21.Text = "A normal CheckBox : TextAlign=BottomCenter";
			this.checkBox21.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// checkBox20
			// 
			this.checkBox20.Location = new System.Drawing.Point(288, 224);
			this.checkBox20.Name = "checkBox20";
			this.checkBox20.Size = new System.Drawing.Size(280, 24);
			this.checkBox20.TabIndex = 26;
			this.checkBox20.Text = "A normal CheckBox : TextAlign=BottomLeft";
			this.checkBox20.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// checkBox27
			// 
			this.checkBox27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBox27.Location = new System.Drawing.Point(288, 384);
			this.checkBox27.Name = "checkBox27";
			this.checkBox27.Size = new System.Drawing.Size(280, 24);
			this.checkBox27.TabIndex = 32;
			this.checkBox27.Text = "A normal CheckBox : Font.Bold=True";
			// 
			// checkBox26
			// 
			this.checkBox26.BackColor = System.Drawing.Color.Green;
			this.checkBox26.Location = new System.Drawing.Point(8, 368);
			this.checkBox26.Name = "checkBox26";
			this.checkBox26.Size = new System.Drawing.Size(264, 24);
			this.checkBox26.TabIndex = 31;
			this.checkBox26.Text = "A normal CheckBox : BackColor=Green";
			// 
			// checkBox25
			// 
			this.checkBox25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.checkBox25.Location = new System.Drawing.Point(288, 352);
			this.checkBox25.Name = "checkBox25";
			this.checkBox25.Size = new System.Drawing.Size(280, 24);
			this.checkBox25.TabIndex = 30;
			this.checkBox25.Text = "A normal CheckBox : FlatStyle=Popup";
			// 
			// checkBox24
			// 
			this.checkBox24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.checkBox24.Location = new System.Drawing.Point(288, 320);
			this.checkBox24.Name = "checkBox24";
			this.checkBox24.Size = new System.Drawing.Size(280, 24);
			this.checkBox24.TabIndex = 29;
			this.checkBox24.Text = "A normal CheckBox : FlatStyle=Flat";
			// 
			// checkBox9
			// 
			this.checkBox9.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.checkBox9.Location = new System.Drawing.Point(8, 264);
			this.checkBox9.Name = "checkBox9";
			this.checkBox9.Size = new System.Drawing.Size(264, 32);
			this.checkBox9.TabIndex = 16;
			this.checkBox9.Text = "A normal CheckBox : CheckAlign=BottomCenter";
			// 
			// checkBox8
			// 
			this.checkBox8.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.checkBox8.Location = new System.Drawing.Point(8, 232);
			this.checkBox8.Name = "checkBox8";
			this.checkBox8.Size = new System.Drawing.Size(264, 24);
			this.checkBox8.TabIndex = 15;
			this.checkBox8.Text = "A normal CheckBox : CheckAlign=BottomLeft";
			// 
			// checkBox3
			// 
			this.checkBox3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.checkBox3.Location = new System.Drawing.Point(8, 64);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new System.Drawing.Size(264, 24);
			this.checkBox3.TabIndex = 2;
			this.checkBox3.Text = "A normal CheckBox: CheckAlign=MiddleCenter";
			// 
			// checkBox2
			// 
			this.checkBox2.Location = new System.Drawing.Point(8, 32);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(264, 24);
			this.checkBox2.TabIndex = 1;
			this.checkBox2.Text = "A normal CheckBox";
			// 
			// checkBox5
			// 
			this.checkBox5.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBox5.Location = new System.Drawing.Point(8, 128);
			this.checkBox5.Name = "checkBox5";
			this.checkBox5.Size = new System.Drawing.Size(264, 24);
			this.checkBox5.TabIndex = 12;
			this.checkBox5.Text = "A normal CheckBox :  CheckAlign=TopLeft";
			// 
			// checkBox4
			// 
			this.checkBox4.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBox4.Location = new System.Drawing.Point(8, 96);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new System.Drawing.Size(264, 24);
			this.checkBox4.TabIndex = 3;
			this.checkBox4.Text = "A normal CheckBox : CheckAlign=MiddleRight";
			// 
			// checkBox7
			// 
			this.checkBox7.CheckAlign = System.Drawing.ContentAlignment.TopRight;
			this.checkBox7.Location = new System.Drawing.Point(8, 200);
			this.checkBox7.Name = "checkBox7";
			this.checkBox7.Size = new System.Drawing.Size(264, 24);
			this.checkBox7.TabIndex = 14;
			this.checkBox7.Text = "A normal CheckBox : CheckAlign=TopRight";
			// 
			// checkBox6
			// 
			this.checkBox6.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
			this.checkBox6.Location = new System.Drawing.Point(8, 160);
			this.checkBox6.Name = "checkBox6";
			this.checkBox6.Size = new System.Drawing.Size(264, 32);
			this.checkBox6.TabIndex = 13;
			this.checkBox6.Text = "A normal CheckBox : CheckAlign=TopCenter";
			// 
			// checkBox32
			// 
			this.checkBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBox32.Location = new System.Drawing.Point(8, 432);
			this.checkBox32.Name = "checkBox32";
			this.checkBox32.Size = new System.Drawing.Size(264, 24);
			this.checkBox32.TabIndex = 37;
			this.checkBox32.Text = "A normal CheckBox : FontSize=10";
			// 
			// checkBox33
			// 
			this.checkBox33.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBox33.Location = new System.Drawing.Point(8, 464);
			this.checkBox33.Name = "checkBox33";
			this.checkBox33.Size = new System.Drawing.Size(264, 24);
			this.checkBox33.TabIndex = 38;
			this.checkBox33.Text = "A normal CheckBox : Font=Verdana";
			// 
			// checkBox30
			// 
			this.checkBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Strikeout, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBox30.Location = new System.Drawing.Point(288, 448);
			this.checkBox30.Name = "checkBox30";
			this.checkBox30.Size = new System.Drawing.Size(280, 24);
			this.checkBox30.TabIndex = 35;
			this.checkBox30.Text = "A normal CheckBox : Font.StrikeOut=True";
			// 
			// checkBox31
			// 
			this.checkBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBox31.Location = new System.Drawing.Point(288, 480);
			this.checkBox31.Name = "checkBox31";
			this.checkBox31.Size = new System.Drawing.Size(280, 24);
			this.checkBox31.TabIndex = 36;
			this.checkBox31.Text = "A normal CheckBox : Font.UnderLine=True";
			// 
			// checkBox34
			// 
			this.checkBox34.Appearance = System.Windows.Forms.Appearance.Button;
			this.checkBox34.Location = new System.Drawing.Point(8, 496);
			this.checkBox34.Name = "checkBox34";
			this.checkBox34.Size = new System.Drawing.Size(264, 24);
			this.checkBox34.TabIndex = 39;
			this.checkBox34.Text = "A normal CheckBox : Appearance=Button";
			// 
			// MainForm
			// 
			this.ClientSize = new System.Drawing.Size(584, 590);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
						this.checkBox34,
						this.checkBox33,
						this.checkBox32,
						this.checkBox31,
						this.checkBox30,
						this.checkBox29,
						this.checkBox28,
						this.checkBox27,
						this.checkBox26,
						this.checkBox25,
						this.checkBox24,
						this.checkBox23,
						this.checkBox21,
						this.checkBox20,
						this.checkBox19,
						this.checkBox18,
						this.checkBox17,
						this.checkBox16,
						this.checkBox15,
						this.checkBox13,
						this.checkBox11,
						this.checkBox14,
						this.checkBox10,
						this.checkBox9,
						this.checkBox8,
						this.checkBox7,
						this.checkBox6,
						this.checkBox5,
						this.checkBox12,
						this.checkBox4,
						this.checkBox3,
						this.checkBox2,
						this.checkBox});
			this.Text = "SWF - CheckBoxes";
			this.ResumeLayout(false);
		}
			
		[STAThread]
		public static void Main(string[] args)
		{
			Application.Run(new MainForm());
		}
	}			
}
