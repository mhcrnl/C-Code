using System;
using System.Windows.Forms;

namespace MyFormProject 
{
	class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.GroupBox groupBox8;
		private System.Windows.Forms.GroupBox groupBox9;
		private System.Windows.Forms.GroupBox groupBox10;
		private System.Windows.Forms.GroupBox groupBox11;
		private System.Windows.Forms.GroupBox groupBox12;
		private System.Windows.Forms.GroupBox groupBox13;
		private System.Windows.Forms.GroupBox groupBox14;
		private System.Windows.Forms.GroupBox groupBox15;
		private System.Windows.Forms.GroupBox groupBox16;
		public MainForm()
		{
			InitializeComponent();
		}
	
		// THIS METHOD IS MAINTAINED BY THE FORM DESIGNER
		// DO NOT EDIT IT MANUALLY! YOUR CHANGES ARE LIKELY TO BE LOST
		void InitializeComponent() {
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.groupBox = new System.Windows.Forms.GroupBox();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.groupBox11 = new System.Windows.Forms.GroupBox();
			this.groupBox10 = new System.Windows.Forms.GroupBox();
			this.groupBox13 = new System.Windows.Forms.GroupBox();
			this.groupBox12 = new System.Windows.Forms.GroupBox();
			this.groupBox14 = new System.Windows.Forms.GroupBox();
			this.groupBox15 = new System.Windows.Forms.GroupBox();
			this.groupBox16 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.SuspendLayout();
			// 
			// groupBox6
			// 
			this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.groupBox6.Location = new System.Drawing.Point(8, 168);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(248, 32);
			this.groupBox6.TabIndex = 5;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "A normal GroupBox : FlatStyle=Flat";
			// 
			// groupBox7
			// 
			this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.groupBox7.Location = new System.Drawing.Point(8, 208);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(248, 32);
			this.groupBox7.TabIndex = 6;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "A normal GroupBox : FlatStyle=Popup";
			// 
			// groupBox
			// 
			this.groupBox.Location = new System.Drawing.Point(8, 48);
			this.groupBox.Name = "groupBox";
			this.groupBox.Size = new System.Drawing.Size(248, 32);
			this.groupBox.TabIndex = 0;
			this.groupBox.TabStop = false;
			this.groupBox.Text = "A normal GroupBox";
			// 
			// groupBox8
			// 
			this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox8.Location = new System.Drawing.Point(272, 56);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new System.Drawing.Size(248, 32);
			this.groupBox8.TabIndex = 7;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "A normal GroupBox : Font.Bold=True";
			// 
			// groupBox9
			// 
			this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox9.Location = new System.Drawing.Point(272, 96);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new System.Drawing.Size(248, 32);
			this.groupBox9.TabIndex = 8;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "A normal GroupBox : Font.Italic=True";
			// 
			// groupBox11
			// 
			this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox11.Location = new System.Drawing.Point(272, 176);
			this.groupBox11.Name = "groupBox11";
			this.groupBox11.Size = new System.Drawing.Size(248, 32);
			this.groupBox11.TabIndex = 10;
			this.groupBox11.TabStop = false;
			this.groupBox11.Text = "A normal GroupBox : Font.Underline=True";
			// 
			// groupBox10
			// 
			this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Strikeout, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox10.Location = new System.Drawing.Point(272, 136);
			this.groupBox10.Name = "groupBox10";
			this.groupBox10.Size = new System.Drawing.Size(248, 32);
			this.groupBox10.TabIndex = 9;
			this.groupBox10.TabStop = false;
			this.groupBox10.Text = "A normal GroupBox : Font.Strikeout=True";
			// 
			// groupBox13
			// 
			this.groupBox13.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox13.Location = new System.Drawing.Point(272, 256);
			this.groupBox13.Name = "groupBox13";
			this.groupBox13.Size = new System.Drawing.Size(280, 32);
			this.groupBox13.TabIndex = 12;
			this.groupBox13.TabStop = false;
			this.groupBox13.Text = "A normal GroupBox : Font=Verdana; 8,25pt";
			// 
			// groupBox12
			// 
			this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox12.Location = new System.Drawing.Point(272, 216);
			this.groupBox12.Name = "groupBox12";
			this.groupBox12.Size = new System.Drawing.Size(248, 32);
			this.groupBox12.TabIndex = 11;
			this.groupBox12.TabStop = false;
			this.groupBox12.Text = "A normal GroupBox : Font.Size=10";
			// 
			// groupBox14
			// 
			this.groupBox14.ForeColor = System.Drawing.Color.Red;
			this.groupBox14.Location = new System.Drawing.Point(8, 248);
			this.groupBox14.Name = "groupBox14";
			this.groupBox14.Size = new System.Drawing.Size(248, 32);
			this.groupBox14.TabIndex = 13;
			this.groupBox14.TabStop = false;
			this.groupBox14.Text = "A normal GroupBox : Font.ForeColor=Red";
			// 
			// groupBox15
			// 
			this.groupBox15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
						| System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox15.Location = new System.Drawing.Point(8, 288);
			this.groupBox15.Name = "groupBox15";
			this.groupBox15.Size = new System.Drawing.Size(248, 32);
			this.groupBox15.TabIndex = 14;
			this.groupBox15.TabStop = false;
			this.groupBox15.Text = "A normal GroupBox : Anchor=All";
			// 
			// groupBox2
			// 
			this.groupBox2.Enabled = false;
			this.groupBox2.Location = new System.Drawing.Point(8, 88);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(248, 32);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "A normal GroupBox : Enabled=False";
			// 
			// groupBox3
			// 
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox3.Location = new System.Drawing.Point(0, 0);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(584, 32);
			this.groupBox3.TabIndex = 2;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "A normal GroupBox : Dock=Top";
			// 
			// groupBox4
			// 
			this.groupBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.groupBox4.Location = new System.Drawing.Point(0, 333);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(584, 32);
			this.groupBox4.TabIndex = 3;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "A normal GroupBox : Dock=Bottom";
			// 
			// groupBox5
			// 
			this.groupBox5.BackColor = System.Drawing.Color.Red;
			this.groupBox5.Location = new System.Drawing.Point(8, 128);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(248, 32);
			this.groupBox5.TabIndex = 4;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "A normal GroupBox : BackColor=Red";
			
			// 
			// groupBox16
			// 			
			this.groupBox16.Location = new System.Drawing.Point(272, 300);
			this.groupBox16.Name = "groupBox16";
			this.groupBox16.Size = new System.Drawing.Size(280, 32);
			this.groupBox16.TabIndex = 12;
			this.groupBox16.TabStop = false;
			
			
			// 
			// MainForm
			// 
			this.ClientSize = new System.Drawing.Size(584, 365);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
						this.groupBox16,
						this.groupBox15,
						this.groupBox14,
						this.groupBox13,
						this.groupBox12,
						this.groupBox11,
						this.groupBox10,
						this.groupBox9,
						this.groupBox8,
						this.groupBox7,
						this.groupBox6,
						this.groupBox5,
						this.groupBox4,
						this.groupBox3,
						this.groupBox2,
						this.groupBox});
			this.Text = "SWF-GroupBoxes";
			this.ResumeLayout(false);
		}
			
		[STAThread]
		public static void Main(string[] args)
		{
			Application.Run(new MainForm());
		}
	}			
}
