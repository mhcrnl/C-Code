// created on 28/07/2003 at 23:26
using System;
using System.Windows.Forms;

namespace MyFormProject {
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RadioButton radioButton31;
		private System.Windows.Forms.RadioButton radioButton30;
		private System.Windows.Forms.RadioButton radioButton33;
		private System.Windows.Forms.RadioButton radioButton;
		private System.Windows.Forms.RadioButton radioButton20;
		private System.Windows.Forms.RadioButton radioButton21;
		private System.Windows.Forms.RadioButton radioButton22;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.RadioButton radioButton25;
		private System.Windows.Forms.RadioButton radioButton26;
		private System.Windows.Forms.RadioButton radioButton6;
		private System.Windows.Forms.RadioButton radioButton7;
		private System.Windows.Forms.RadioButton radioButton4;
		private System.Windows.Forms.RadioButton radioButton5;
		private System.Windows.Forms.RadioButton radioButton8;
		private System.Windows.Forms.RadioButton radioButton9;
		private System.Windows.Forms.RadioButton radioButton32;
		private System.Windows.Forms.RadioButton radioButton23;
		private System.Windows.Forms.RadioButton radioButton24;
		private System.Windows.Forms.RadioButton radioButton27;
		private System.Windows.Forms.RadioButton radioButton28;
		private System.Windows.Forms.RadioButton radioButton29;
		private System.Windows.Forms.RadioButton radioButton13;
		private System.Windows.Forms.RadioButton radioButton12;
		private System.Windows.Forms.RadioButton radioButton11;
		private System.Windows.Forms.RadioButton radioButton10;
		private System.Windows.Forms.RadioButton radioButton17;
		private System.Windows.Forms.RadioButton radioButton16;
		private System.Windows.Forms.RadioButton radioButton15;
		private System.Windows.Forms.RadioButton radioButton14;
		private System.Windows.Forms.RadioButton radioButton19;
		private System.Windows.Forms.RadioButton radioButton18;
		public MainForm()
		{
			InitializeComponent();
		}
		
		// THIS METHOD IS MAINTAINED BY THE FORM DESIGNER
		// DO NOT EDIT IT MANUALLY! YOUR CHANGES ARE LIKELY TO BE LOST
		void InitializeComponent() {
			this.radioButton18 = new System.Windows.Forms.RadioButton();
			this.radioButton19 = new System.Windows.Forms.RadioButton();
			this.radioButton14 = new System.Windows.Forms.RadioButton();
			this.radioButton15 = new System.Windows.Forms.RadioButton();
			this.radioButton16 = new System.Windows.Forms.RadioButton();
			this.radioButton17 = new System.Windows.Forms.RadioButton();
			this.radioButton10 = new System.Windows.Forms.RadioButton();
			this.radioButton11 = new System.Windows.Forms.RadioButton();
			this.radioButton12 = new System.Windows.Forms.RadioButton();
			this.radioButton13 = new System.Windows.Forms.RadioButton();
			this.radioButton29 = new System.Windows.Forms.RadioButton();
			this.radioButton28 = new System.Windows.Forms.RadioButton();
			this.radioButton27 = new System.Windows.Forms.RadioButton();
			this.radioButton24 = new System.Windows.Forms.RadioButton();
			this.radioButton23 = new System.Windows.Forms.RadioButton();
			this.radioButton32 = new System.Windows.Forms.RadioButton();
			this.radioButton9 = new System.Windows.Forms.RadioButton();
			this.radioButton8 = new System.Windows.Forms.RadioButton();
			this.radioButton5 = new System.Windows.Forms.RadioButton();
			this.radioButton4 = new System.Windows.Forms.RadioButton();
			this.radioButton7 = new System.Windows.Forms.RadioButton();
			this.radioButton6 = new System.Windows.Forms.RadioButton();
			this.radioButton26 = new System.Windows.Forms.RadioButton();
			this.radioButton25 = new System.Windows.Forms.RadioButton();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton22 = new System.Windows.Forms.RadioButton();
			this.radioButton21 = new System.Windows.Forms.RadioButton();
			this.radioButton20 = new System.Windows.Forms.RadioButton();
			this.radioButton = new System.Windows.Forms.RadioButton();
			this.radioButton33 = new System.Windows.Forms.RadioButton();
			this.radioButton30 = new System.Windows.Forms.RadioButton();
			this.radioButton31 = new System.Windows.Forms.RadioButton();
			this.SuspendLayout();
			// 
			// radioButton18
			// 
			this.radioButton18.Location = new System.Drawing.Point(8, 368);
			this.radioButton18.Name = "radioButton18";
			this.radioButton18.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.radioButton18.Size = new System.Drawing.Size(288, 24);
			this.radioButton18.TabIndex = 17;
			this.radioButton18.Text = "A normal RadioButton : RightToLeft=True";
			// 
			// radioButton19
			// 
			this.radioButton19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton19.Location = new System.Drawing.Point(312, 352);
			this.radioButton19.Name = "radioButton19";
			this.radioButton19.Size = new System.Drawing.Size(288, 24);
			this.radioButton19.TabIndex = 18;
			this.radioButton19.Text = "A normal RadioButton : Font.Bold=True";
			// 
			// radioButton14
			// 
			this.radioButton14.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
			this.radioButton14.Location = new System.Drawing.Point(8, 128);
			this.radioButton14.Name = "radioButton14";
			this.radioButton14.Size = new System.Drawing.Size(288, 24);
			this.radioButton14.TabIndex = 13;
			this.radioButton14.Text = "A normal RadioButton :  CheckAlign=TopLeft";
			// 
			// radioButton15
			// 
			this.radioButton15.Dock = System.Windows.Forms.DockStyle.Top;
			this.radioButton15.Location = new System.Drawing.Point(0, 0);
			this.radioButton15.Name = "radioButton15";
			this.radioButton15.Size = new System.Drawing.Size(608, 24);
			this.radioButton15.TabIndex = 14;
			this.radioButton15.Text = "A normal RadioButton: Dock=Top";
			// 
			// radioButton16
			// 
			this.radioButton16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton16.Location = new System.Drawing.Point(312, 448);
			this.radioButton16.Name = "radioButton16";
			this.radioButton16.Size = new System.Drawing.Size(288, 24);
			this.radioButton16.TabIndex = 39;
			this.radioButton16.Text = "A normal RadioButton : Font.Underline=True";
			// 
			// radioButton17
			// 
			this.radioButton17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radioButton17.Location = new System.Drawing.Point(312, 288);
			this.radioButton17.Name = "radioButton17";
			this.radioButton17.Size = new System.Drawing.Size(288, 24);
			this.radioButton17.TabIndex = 16;
			this.radioButton17.Text = "A normal RadioButton : FlatStyle=Flat";
			// 
			// radioButton10
			// 
			this.radioButton10.BackColor = System.Drawing.Color.SeaGreen;
			this.radioButton10.Location = new System.Drawing.Point(8, 400);
			this.radioButton10.Name = "radioButton10";
			this.radioButton10.Size = new System.Drawing.Size(288, 24);
			this.radioButton10.TabIndex = 9;
			this.radioButton10.Text = "A normal RadioButton : BackColor=SeaGreen";
			// 
			// radioButton11
			// 
			this.radioButton11.Location = new System.Drawing.Point(312, 32);
			this.radioButton11.Name = "radioButton11";
			this.radioButton11.Size = new System.Drawing.Size(288, 24);
			this.radioButton11.TabIndex = 10;
			this.radioButton11.Text = "A normal RadioButton : TextAlign=MiddleCenter";
			this.radioButton11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// radioButton12
			// 
			this.radioButton12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.radioButton12.Location = new System.Drawing.Point(312, 320);
			this.radioButton12.Name = "radioButton12";
			this.radioButton12.Size = new System.Drawing.Size(288, 24);
			this.radioButton12.TabIndex = 37;
			this.radioButton12.Text = "A normal RadioButton : FlatStyle=Popup";
			// 
			// radioButton13
			// 
			this.radioButton13.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.radioButton13.Location = new System.Drawing.Point(8, 232);
			this.radioButton13.Name = "radioButton13";
			this.radioButton13.Size = new System.Drawing.Size(288, 24);
			this.radioButton13.TabIndex = 12;
			this.radioButton13.Text = "A normal RadioButton : CheckAlign=BottomLeft";
			// 
			// radioButton29
			// 
			this.radioButton29.Location = new System.Drawing.Point(312, 256);
			this.radioButton29.Name = "radioButton29";
			this.radioButton29.Size = new System.Drawing.Size(288, 24);
			this.radioButton29.TabIndex = 36;
			this.radioButton29.Text = "A normal RadioButton : TextAlign=BottomRight";
			this.radioButton29.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// radioButton28
			// 
			this.radioButton28.Location = new System.Drawing.Point(312, 224);
			this.radioButton28.Name = "radioButton28";
			this.radioButton28.Size = new System.Drawing.Size(288, 24);
			this.radioButton28.TabIndex = 35;
			this.radioButton28.Text = "A normal RadioButton : TextAlign=BottomCenter";
			this.radioButton28.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// radioButton27
			// 
			this.radioButton27.Location = new System.Drawing.Point(312, 192);
			this.radioButton27.Name = "radioButton27";
			this.radioButton27.Size = new System.Drawing.Size(288, 24);
			this.radioButton27.TabIndex = 34;
			this.radioButton27.Text = "A normal RadioButton : TextAlign=BottomLeft";
			this.radioButton27.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// radioButton24
			// 
			this.radioButton24.Location = new System.Drawing.Point(312, 160);
			this.radioButton24.Name = "radioButton24";
			this.radioButton24.Size = new System.Drawing.Size(288, 24);
			this.radioButton24.TabIndex = 33;
			this.radioButton24.Text = "A normal RadioButton : TextAlign=TopRight";
			this.radioButton24.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// radioButton23
			// 
			this.radioButton23.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.radioButton23.Location = new System.Drawing.Point(8, 96);
			this.radioButton23.Name = "radioButton23";
			this.radioButton23.Size = new System.Drawing.Size(288, 24);
			this.radioButton23.TabIndex = 26;
			this.radioButton23.Text = "A normal RadioButton : CheckAlign=MiddleRight";
			// 
			// radioButton32
			// 
			this.radioButton32.ForeColor = System.Drawing.Color.Green;
			this.radioButton32.Location = new System.Drawing.Point(8, 432);
			this.radioButton32.Name = "radioButton32";
			this.radioButton32.Size = new System.Drawing.Size(288, 24);
			this.radioButton32.TabIndex = 42;
			this.radioButton32.Text = "A normal RadioButton : ForeColor=Green";
			// 
			// radioButton9
			// 
			this.radioButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton9.Location = new System.Drawing.Point(312, 384);
			this.radioButton9.Name = "radioButton9";
			this.radioButton9.Size = new System.Drawing.Size(288, 24);
			this.radioButton9.TabIndex = 8;
			this.radioButton9.Text = "A normal RadioButton : Font.Italic=True";
			// 
			// radioButton8
			// 
			this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Strikeout, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton8.Location = new System.Drawing.Point(312, 416);
			this.radioButton8.Name = "radioButton8";
			this.radioButton8.Size = new System.Drawing.Size(288, 24);
			this.radioButton8.TabIndex = 38;
			this.radioButton8.Text = "A normal RadioButton : Font.Strikeout=True";
			// 
			// radioButton5
			// 
			this.radioButton5.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.radioButton5.Location = new System.Drawing.Point(0, 541);
			this.radioButton5.Name = "radioButton5";
			this.radioButton5.Size = new System.Drawing.Size(608, 24);
			this.radioButton5.TabIndex = 4;
			this.radioButton5.Text = "A normal RadioButton : Dock = Bottom";
			// 
			// radioButton4
			// 
			this.radioButton4.CheckAlign = System.Drawing.ContentAlignment.TopRight;
			this.radioButton4.Location = new System.Drawing.Point(8, 200);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.Size = new System.Drawing.Size(288, 24);
			this.radioButton4.TabIndex = 3;
			this.radioButton4.Text = "A normal RadioButton : CheckAlign=TopRight";
			// 
			// radioButton7
			// 
			this.radioButton7.Checked = true;
			this.radioButton7.Location = new System.Drawing.Point(8, 336);
			this.radioButton7.Name = "radioButton7";
			this.radioButton7.Size = new System.Drawing.Size(288, 24);
			this.radioButton7.TabIndex = 6;
			this.radioButton7.TabStop = true;
			this.radioButton7.Text = "A normal RadioButton : Checked=True";
			// 
			// radioButton6
			// 
			this.radioButton6.Location = new System.Drawing.Point(8, 32);
			this.radioButton6.Name = "radioButton6";
			this.radioButton6.Size = new System.Drawing.Size(288, 24);
			this.radioButton6.TabIndex = 22;
			this.radioButton6.Text = "A normal RadioButton";
			// 
			// radioButton26
			// 
			this.radioButton26.Location = new System.Drawing.Point(312, 96);
			this.radioButton26.Name = "radioButton26";
			this.radioButton26.Size = new System.Drawing.Size(288, 24);
			this.radioButton26.TabIndex = 31;
			this.radioButton26.Text = "A normal RadioButton : TextAlign=TopLeft";
			this.radioButton26.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			// 
			// radioButton25
			// 
			this.radioButton25.Location = new System.Drawing.Point(312, 128);
			this.radioButton25.Name = "radioButton25";
			this.radioButton25.Size = new System.Drawing.Size(288, 24);
			this.radioButton25.TabIndex = 32;
			this.radioButton25.Text = "A normal RadioButton : TextAlign=TopCenter";
			this.radioButton25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// radioButton3
			// 
			this.radioButton3.CheckAlign = System.Drawing.ContentAlignment.BottomRight;
			this.radioButton3.Location = new System.Drawing.Point(8, 304);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.Size = new System.Drawing.Size(288, 24);
			this.radioButton3.TabIndex = 2;
			this.radioButton3.Text = "A normal RadioButton : CheckAlign=BottomRight";
			// 
			// radioButton2
			// 
			this.radioButton2.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
			this.radioButton2.Location = new System.Drawing.Point(8, 160);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(288, 32);
			this.radioButton2.TabIndex = 1;
			this.radioButton2.Text = "A normal RadioButton : CheckAlign=TopCenter";
			// 
			// radioButton22
			// 
			this.radioButton22.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.radioButton22.Location = new System.Drawing.Point(8, 64);
			this.radioButton22.Name = "radioButton22";
			this.radioButton22.Size = new System.Drawing.Size(288, 24);
			this.radioButton22.TabIndex = 25;
			this.radioButton22.Text = "A normal RadioButton : CheckAlign=MiddleCenter";
			// 
			// radioButton21
			// 
			this.radioButton21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
						| System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.radioButton21.Location = new System.Drawing.Point(8, 496);
			this.radioButton21.Name = "radioButton21";
			this.radioButton21.Size = new System.Drawing.Size(288, 24);
			this.radioButton21.TabIndex = 21;
			this.radioButton21.Text = "A normal RadioButton : Anchor=All";
			// 
			// radioButton20
			// 
			this.radioButton20.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.radioButton20.Location = new System.Drawing.Point(8, 264);
			this.radioButton20.Name = "radioButton20";
			this.radioButton20.Size = new System.Drawing.Size(288, 32);
			this.radioButton20.TabIndex = 23;
			this.radioButton20.Text = "A normal RadioButton : CheckAlign=BottomCenter";
			// 
			// radioButton
			// 
			this.radioButton.Location = new System.Drawing.Point(312, 64);
			this.radioButton.Name = "radioButton";
			this.radioButton.Size = new System.Drawing.Size(288, 24);
			this.radioButton.TabIndex = 0;
			this.radioButton.Text = "A normal RadioButton : TextAlign=MiddleRight";
			this.radioButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// radioButton33
			// 
			this.radioButton33.Appearance = System.Windows.Forms.Appearance.Button;
			this.radioButton33.Location = new System.Drawing.Point(312, 512);
			this.radioButton33.Name = "radioButton33";
			this.radioButton33.Size = new System.Drawing.Size(288, 24);
			this.radioButton33.TabIndex = 43;
			this.radioButton33.Text = "A normal RadioButton : Appearance=Button";
			// 
			// radioButton30
			// 
			this.radioButton30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton30.Location = new System.Drawing.Point(8, 464);
			this.radioButton30.Name = "radioButton30";
			this.radioButton30.Size = new System.Drawing.Size(288, 24);
			this.radioButton30.TabIndex = 40;
			this.radioButton30.Text = "A normal RadioButton : Font.Size=10";
			// 
			// radioButton31
			// 
			this.radioButton31.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton31.Location = new System.Drawing.Point(312, 480);
			this.radioButton31.Name = "radioButton31";
			this.radioButton31.Size = new System.Drawing.Size(288, 24);
			this.radioButton31.TabIndex = 41;
			this.radioButton31.Text = "A normal RadioButton : Font=Verdana; 8,25pt";
			// 
			// CreatedForm
			// 
			this.ClientSize = new System.Drawing.Size(608, 565);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
						this.radioButton33,
						this.radioButton32,
						this.radioButton31,
						this.radioButton30,
						this.radioButton16,
						this.radioButton8,
						this.radioButton12,
						this.radioButton29,
						this.radioButton28,
						this.radioButton27,
						this.radioButton24,
						this.radioButton25,
						this.radioButton26,
						this.radioButton23,
						this.radioButton22,
						this.radioButton20,
						this.radioButton6,
						this.radioButton21,
						this.radioButton19,
						this.radioButton18,
						this.radioButton17,
						this.radioButton15,
						this.radioButton14,
						this.radioButton13,
						this.radioButton11,
						this.radioButton10,
						this.radioButton9,
						this.radioButton7,
						this.radioButton5,
						this.radioButton4,
						this.radioButton3,
						this.radioButton2,
						this.radioButton});
			this.Text = "SWF-RadioButtons";
			this.ResumeLayout(false);
		}

		[STAThread]
       	public static void Main(string[] args)
       	{
       		Application.Run(new MainForm());
        }

	}
}
